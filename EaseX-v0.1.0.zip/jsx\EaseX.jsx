/* EaseX host logic. Value mode creates real intermediate bounce keyframes. */
var EaseX = EaseX || {};
EaseX.apply = function (incomingInfluence, outgoingInfluence, incomingY, outgoingY, perKeyframe, valueMode, overshootPercent, bounceCount) {
    function easeArray(property, speed, influence) { var count = property.value instanceof Array ? property.value.length : 1, result = [], ease = new KeyframeEase(speed, influence); for (var i = 0; i < count; i++) { result.push(ease); } return result; }
    function distance(a, b) { if (a instanceof Array) { var total = 0; for (var i = 0; i < a.length; i++) { total += Math.pow(a[i] - b[i], 2); } return Math.sqrt(total); } return Math.abs(a - b); }
    function baseSpeed(property, keyIndex, incoming) { var other = incoming ? keyIndex - 1 : keyIndex + 1; if (other < 1 || other > property.numKeys) { return 0; } var duration = Math.abs(property.keyTime(keyIndex) - property.keyTime(other)); return duration > 0 ? distance(property.keyValue(keyIndex), property.keyValue(other)) / duration : 0; }
    function speedFromY(y, incoming, base) { var travel = incoming ? y - 20 : 170 - y; return Math.max(0, Math.min(2, travel / 150 * 2)) * base; }
    function isNumericValue(value) { return typeof value === 'number' || value instanceof Array; }
    function bounceValue(start, end, percent) { if (typeof start === 'number') { return end + (end - start) * percent; } var result = []; for (var i = 0; i < start.length; i++) { result.push(end[i] + (end[i] - start[i]) * percent); } return result; }
    function applyBounce(property, keys, percent, count) { var created = 0; for (var pair = keys.length - 2; pair >= 0; pair--) { var startTime = keys[pair].time, endTime = keys[pair + 1].time, startValue = keys[pair].value, endValue = keys[pair + 1].value, duration = endTime - startTime; if (duration <= 0 || !isNumericValue(startValue) || !isNumericValue(endValue)) { continue; } for (var b = 0; b < count; b++) { var time = startTime + duration * (0.68 + b * (0.20 / count)), direction = b % 2 === 0 ? 1 : -1, value = bounceValue(startValue, endValue, percent * direction / (b + 1)); property.setValueAtTime(time, value); var index = property.nearestKeyIndex(time); property.setInterpolationTypeAtKey(index, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER); created++; } } return created; }
    try {
        if (!app.project || !(app.project.activeItem instanceof CompItem)) { return 'ERRO: Abra uma composicao e selecione keyframes.'; }
        incomingInfluence = Math.max(0.1, Math.min(100, Number(incomingInfluence))); outgoingInfluence = Math.max(0.1, Math.min(100, Number(outgoingInfluence))); incomingY = Math.max(2, Math.min(188, Number(incomingY))); outgoingY = Math.max(2, Math.min(188, Number(outgoingY))); overshootPercent = Math.max(-1, Math.min(1, Number(overshootPercent) / 100)); bounceCount = Math.max(1, Math.min(3, Math.round(Number(bounceCount))));
        var properties = app.project.activeItem.selectedProperties, applied = 0, created = 0;
        if (!properties || properties.length === 0) { return 'ERRO: Selecione ao menos um keyframe.'; }
        app.beginUndoGroup(valueMode ? 'EaseX - Apply value bounce' : 'EaseX - Apply curve');
        for (var p = 0; p < properties.length; p++) {
            var property = properties[p]; if (!property || !property.canVaryOverTime || property.numKeys === 0) { continue; }
            var selected = [];
            for (var k = 1; k <= property.numKeys; k++) { if (property.keySelected(k)) { selected.push({ time: property.keyTime(k), value: property.keyValue(k), index: k }); } }
            if (valueMode) { if (selected.length >= 2) { created += applyBounce(property, selected, overshootPercent, bounceCount); } continue; }
            for (var s = 0; s < selected.length; s++) { var index = selected[s].index; property.setInterpolationTypeAtKey(index, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER); var inSpeed = speedFromY(incomingY, true, baseSpeed(property, index, true)), outSpeed = speedFromY(outgoingY, false, baseSpeed(property, index, false)); property.setTemporalEaseAtKey(index, easeArray(property, inSpeed, incomingInfluence), easeArray(property, outSpeed, outgoingInfluence)); applied++; }
        }
        app.endUndoGroup();
        if (valueMode) { return created ? 'Created '+created+' bounce keyframe'+(created === 1 ? '' : 's')+'.' : 'ERRO: No Value Graph, selecione pelo menos dois keyframes por propriedade.'; }
        return applied ? 'Applied to '+applied+' keyframe'+(applied === 1 ? '' : 's')+'.' : 'ERRO: Nenhum keyframe selecionado nas propriedades selecionadas.';
    } catch (error) { try { app.endUndoGroup(); } catch (ignore) {} return 'ERRO: '+error.toString(); }
};
