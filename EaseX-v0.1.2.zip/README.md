# EaseX

EaseX is a CEP panel for Adobe After Effects that applies temporal easing, influence, speed curves, and bounce motion to selected keyframes.

Created by [Bruno Jorri](https://www.instagram.com/brunojorri_work/).

## Features

- Edit incoming and outgoing influence visually or numerically.
- Speed Graph for temporal easing without adding keyframes.
- Value Graph with signed overshoot and 1–3 generated bounce keyframes.
- Built-in curve library and custom saved presets.
- Flip, reset, snap, and linked-handle controls.
- One Undo group for every application.

## Installation

1. Copy the `EaseX` folder to `%APPDATA%\\Adobe\\CEP\\extensions\\com.easex.panel`.
2. Enable `PlayerDebugMode` for `HKCU\\Software\\Adobe\\CSXS.12` when running this unsigned development build.
3. Restart After Effects and open **Window > Extensions > EaseX**.

## Usage

1. Select one or more animated properties and their keyframes.
2. Use **Speed graph** for classic Easy Ease influence and velocity editing.
3. Use **Value graph** to set a signed overshoot. Select at least two keyframes per property; EaseX adds the intermediate bounce keyframes when you click **Apply**.
4. Save a custom preset to reuse the current curve.

## Project structure

```
CSXS/manifest.xml   CEP extension manifest
css/style.css       panel appearance
index.html          panel interface
js/main.js          panel interaction logic
jsx/EaseX.jsx       After Effects ExtendScript host logic
```

## Development notes

This repository contains the development version of EaseX. Test on a duplicate composition first, particularly Value Graph, because it intentionally creates intermediate keyframes.

## License

All rights reserved. Contact Bruno Jorri for permission to use, distribute, or modify this project.
